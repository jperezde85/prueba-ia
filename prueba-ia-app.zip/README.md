# Prueba IA

Proyecto desplegable en Vercel. Incluye módulo 1 completo con test autoevaluativo.